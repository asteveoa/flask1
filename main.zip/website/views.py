from flask import Blueprint,render_template,request,flash,url_for,redirect
from flask_login import login_user,login_required,current_user
from werkzeug.security import generate_password_hash,check_password_hash
from .models import User,PatientsPre
from website.forms import SignUpForm,UserProfile,BehaviorForm,SubacuteForm
from . import db
from. import engine
import sqlalchemy as sa

from sqlalchemy import desc
from sqlalchemy.dialects.sqlite import insert


views=Blueprint('views',__name__)

@views.route('/', methods=['GET','POST'])
@login_required
def home():


    if request.method=='POST':


        if request.form.get('name_asc'):
            print('namedec')
            patients = PatientsPre.query.order_by(desc('name_pat_')).all()
            print(patients)

        elif request.form.get('date_dec'):
            print('datedec')
            patients = PatientsPre.query.order_by('date_of_entry_text').all()
            print(patients)


        elif request.form.get('date_asc'):
            print('dateasc')
            patients = PatientsPre.query.order_by(desc('date_of_entry_text')).all()
            print(patients)
        else:
            patients=0


        return render_template('home.html',user=current_user,patients=patients)

    if request.method=='GET':
        name = 0
        try:
            patients = PatientsPre.query.all()
        except:
            patients=None

        return render_template('home.html',user=current_user,patients=patients)
@views.route('/<int:user_id>', methods=['GET','POST'])
@login_required
def behavior_health(user_id):
    form_info=0
    if request.method=='GET':
        if user_id==0: #if user_id is not valid send to form blank
            return render_template('behavior_health.html', user=current_user, patient=form_info)
        else:#if user_id exist open form with existing information
            with engine.connect() as conn:



                qry = sa.text("SELECT * FROM patients_pre WHERE id ="+str(user_id))#query database for selected patient and print it into dict then
                resultset = conn.execute(qry) #make connection to database and query

                results_as_dict = resultset.mappings().all()    #map return out to dictionary
                print(results_as_dict)
                form_info =results_as_dict[0] #slected patient information going into form_id as list
                print(form_info)

            return render_template('behavior_health.html', user=current_user, patient=form_info)
    if request.method=='POST':
        pat_name=request.form.get('pat_name')
        patient = PatientsPre.query.filter_by(name_pat_=pat_name).first()
        if not patient:
            new_patient=PatientsPre(name_pat_=pat_name,user_id=current_user.id)

            db.session.add(new_patient)
            db.session.commit()
        else:
            flash("Patient already exists in database", category='error')
            flash("Returning back to home page", category='info')

            return redirect(url_for('views.home'))








    return render_template('behavior_health.html',user=current_user,patient=form_info)

@views.route('/behavior_health1/<int:id>', methods=['GET', 'POST'])
@login_required
def behavior_health1(id):
    if request.method=='GET':
        if id ==0:
            form = BehaviorForm()
        elif id!='0':

            user = User.query.filter_by(id=id)
            with engine.begin() as conn:
                qry = sa.text("SELECT * FROM patients_pre WHERE id =" + str(
                    id))  # query database for selected user and print it into dict then
                resultset = conn.execute(qry)  # make connection to database and query

                results_as_dict=resultset.mappings().all() # map return out to dictionary

                print(results_as_dict[0])


                form=BehaviorForm(data=results_as_dict[0])#selected patient information going into form data as dictionary obj




    if request.method=="POST":
        form=BehaviorForm()
        pat_name = request.form.get('name_pat_')

        patient = PatientsPre.query.filter_by(name_pat_=pat_name).first()
        print(patient)
        new_dict={}
        if not patient:
            for i, k in request.form.to_dict().items():  # booleans not set to 1 or 2 they are strings have to convert

                if request.form.to_dict()[i] == 'on' or request.form.to_dict()[i] =='y' or request.form.to_dict()[i] =='1':
                    new_dict[i] = True
                elif request.form.to_dict()[i] == '0' or request.form.to_dict()[i] == False:
                    new_dict[i] = False
                elif request.form.to_dict()[i]=='':
                    new_dict[i]=None
                else:
                    new_dict[i] = k
            for i,k in new_dict.items():
                print(i,k)
            new_patient = PatientsPre(**new_dict,user_id=current_user.id)




            db.session.add(new_patient)
            db.session.commit()
            return redirect(url_for('views.home'))
        else:

        #existing patient found

            with engine.begin() as conn:
                qry = sa.text("SELECT * FROM patients_pre WHERE id =" + str(
                    id))  # query database for selected user and print it into dict then
                resultset = conn.execute(qry)  # make connection to database and query

                results_as_dict=resultset.mappings().all() # map return out to dictionary







            for i, k in request.form.to_dict().items():  # booleans not set to 1 or 2 they are strings have to convert

                if request.form.to_dict()[i] == 'on' or request.form.to_dict()[i] =='y' or request.form.to_dict()[i] =='1':#run thru all false returns
                    new_dict[i] = True
                elif request.form.to_dict()[i] =='0' or request.form.to_dict()[i] == False:#change all false returns to false
                    new_dict[i] = None
                elif request.form.to_dict()[i]=='':#Any empty strings clear out of dict
                    request.form.to_dict()[i]==None
                else:
                    new_dict[i] = k    # if none of these add to new dictionary

            print('//////////////////////')
            for i in results_as_dict[0]:
                if i not in request.form.to_dict() and i not in ['id','date_of_entry_text','user_id']:#dont change these parameters in table and if form didnt submit these add these items

                        new_dict[i]=None #None is False and also ""

            print(new_dict)


            db.session.query(PatientsPre).filter(PatientsPre.id == id).update(new_dict)
            db.session.commit()

            flash("Patient already exists in database", category='error')
            flash("Returning back to home page", category='info')

            return redirect(url_for('views.home'))



    return render_template('behavior_health1.html',form=form,user=current_user)

@views.route('/user/<int:id>', methods=['GET', 'POST'])
@login_required
def Profile(id):
    if request.method=='GET':

        user=User.query.filter_by(id=id)
        with engine.begin() as conn:
            qry = sa.text("SELECT * FROM USER WHERE id =" + str(
                id))  # query database for selected user and print it into dict then
            resultset = conn.execute(qry)  # make connection to database and query

            results_as_dict = resultset.mappings().all()  # map return out to dictionary

            form_info = results_as_dict[0]  # slected patient information going into form_id as list
            form=UserProfile(data=form_info)

            return render_template('user.html',form=form, user=current_user, id=current_user.id)
    if request.method=='POST':
        data_user=User.query.filter_by(id=id).first()  #look for user


        data_user.first_name=request.form['first_name'] #change username if changed
        print(data_user.first_name)
        try:
            db.session.commit()
        except:
            print('fail')
        if request.form['ProfilePic']:  # if profile image uploaded
            print(request.form['ProfilePic'])

        flash('updated information',category='success')
        return redirect(url_for('views.Profile',id=current_user.id))


@views.route('/subacute/', methods=['GET', 'POST'])
@login_required
def subacute():
    form=SubacuteForm()


    if request.method=="POST":
        a=request.form
        print(a)
    return render_template('subacute.html',form=form,user=current_user)




@views.route('/chronic/<int:id>', methods=['GET', 'POST'])
@login_required
def chronic(id):
    form = BehaviorForm()
    print(current_user.id)
    return render_template('chronic.html',user=current_user,form=form)



